-- Schema cho trang web bán đồ cũ
-- Tạo bảng users (người dùng)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tạo bảng products (sản phẩm)
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    price INTEGER NOT NULL,
    category VARCHAR(50) NOT NULL,
    condition VARCHAR(20) NOT NULL,
    location VARCHAR(50) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    email VARCHAR(255),
    seller_name VARCHAR(255) NOT NULL,
    images TEXT[],
    created_at TEXT NOT NULL
);

-- Tạo index để tối ưu tìm kiếm
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_condition ON products(condition);
CREATE INDEX IF NOT EXISTS idx_products_location ON products(location);
CREATE INDEX IF NOT EXISTS idx_products_price ON products(price);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at);

-- Tạo index cho tìm kiếm text
CREATE INDEX IF NOT EXISTS idx_products_title ON products USING gin(to_tsvector('vietnamese', title));
CREATE INDEX IF NOT EXISTS idx_products_description ON products USING gin(to_tsvector('vietnamese', description));