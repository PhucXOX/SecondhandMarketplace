-- Dữ liệu mẫu cho trang web bán đồ cũ

-- Xóa dữ liệu cũ (nếu có)
TRUNCATE TABLE products RESTART IDENTITY CASCADE;
TRUNCATE TABLE users RESTART IDENTITY CASCADE;

-- Thêm người dùng mẫu
INSERT INTO users (username, password) VALUES
('admin', '$2b$10$hash_example'),
('user1', '$2b$10$hash_example'),
('user2', '$2b$10$hash_example');

-- Thêm sản phẩm mẫu
INSERT INTO products (title, description, price, category, condition, location, phone, email, seller_name, images, created_at) VALUES
(
    'Máy ảnh Canon EOS 70D kèm lens 18-55mm',
    'Máy ảnh Canon EOS 70D trong tình trạng rất tốt, sử dụng ít. Bao gồm thân máy, lens kit 18-55mm, sạc pin chính hãng, thẻ nhớ 32GB và hộp phụ kiện đầy đủ. Máy chụp ảnh rất đẹp, phù hợp cho người mới bắt đầu học nhiếp ảnh.',
    8500000,
    'electronics',
    'new',
    'hanoi',
    '0901234567',
    'nguyen.a@email.com',
    'Nguyễn Văn A',
    ARRAY['https://images.unsplash.com/photo-1502920917128-1aa500764cbd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'Áo khoác jean vintage Levi''s size M',
    'Áo khoác jean Levi''s vintage authentic, màu xanh đậm, size M. Chất liệu denim cao cấp, thiết kế cổ điển, phù hợp cho cả nam và nữ. Áo được giữ gìn cẩn thận, không có vết rách hay phai màu.',
    450000,
    'fashion',
    'used',
    'hcm',
    '0902345678',
    NULL,
    'Mai Thị B',
    ARRAY['https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'Bộ sách văn học Việt Nam (10 cuốn)',
    'Bộ sách văn học Việt Nam gồm 10 cuốn của các tác giả nổi tiếng như Nguyễn Du, Nam Cao, Tô Hoài... Sách trong tình trạng tốt, không rách hay ố vàng. Phù hợp cho học sinh, sinh viên và người yêu văn học.',
    280000,
    'books',
    'new',
    'danang',
    '0903456789',
    NULL,
    'Hoàng Văn C',
    ARRAY['https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'MacBook Air M1 13inch 256GB',
    'MacBook Air M1 chip 8-core CPU, màn hình 13 inch Retina, bộ nhớ SSD 256GB, RAM 8GB. Máy sử dụng nhẹ trong môi trường văn phòng, pin còn rất tốt (>90%), không có vết xước hay dent. Bao gồm sạc MagSafe và hộp.',
    18500000,
    'electronics',
    'used',
    'hanoi',
    '0904567890',
    NULL,
    'Linh Nguyễn D',
    ARRAY['https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'iPhone 14 Pro 128GB Deep Purple',
    'iPhone 14 Pro màu Deep Purple, bộ nhớ 128GB. Máy mới 99%, sử dụng 3 tháng, còn bảo hành chính hãng 9 tháng. Đầy đủ hộp, sạc Lightning, không có vết trầy xước. Pin health 100%.',
    22000000,
    'electronics',
    'new',
    'hcm',
    '0905678901',
    'tran.b@email.com',
    'Trần Minh B',
    ARRAY['https://images.unsplash.com/photo-1592750475338-74b7b21085ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'Xe đạp Giant ATX 2023 size M',
    'Xe đạp Giant ATX 2023, size M (phù hợp người cao 1m65-1m75), màu xanh lá. Xe ít sử dụng, chỉ đi cuối tuần, các bộ phận còn hoạt động tốt. Bao gồm bình nước và đèn LED.',
    4500000,
    'vehicles',
    'used',
    'danang',
    '0906789012',
    NULL,
    'Phạm Văn E',
    ARRAY['https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'Bàn làm việc gỗ sồi 120x60cm',
    'Bàn làm việc gỗ sồi tự nhiên, kích thước 120x60x75cm. Thiết kế hiện đại, có ngăn kéo tiện lợi. Bàn được sử dụng 6 tháng, còn rất mới, phù hợp cho văn phòng hoặc góc làm việc tại nhà.',
    2800000,
    'home',
    'new',
    'hcm',
    '0907890123',
    'pham.c@email.com',
    'Phạm Thị C',
    ARRAY['https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
),
(
    'Guitar Acoustic Yamaha F310',
    'Guitar Acoustic Yamaha F310, màu gỗ tự nhiên. Đàn trong tình trạng tốt, âm thanh trong trẻo, phù hợp cho người mới học. Bao gồm bao đựng, pick và dây dự phòng.',
    1200000,
    'music',
    'used',
    'hanoi',
    '0908901234',
    NULL,
    'Đặng Văn F',
    ARRAY['https://images.unsplash.com/photo-1516924962500-2b4b3b99ea02?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300'],
    NOW()::text
);