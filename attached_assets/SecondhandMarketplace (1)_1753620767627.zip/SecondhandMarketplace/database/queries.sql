-- Các câu truy vấn SQL phổ biến cho trang web bán đồ cũ

-- 1. Lấy tất cả sản phẩm, sắp xếp theo ngày tạo mới nhất
SELECT * FROM products 
ORDER BY created_at DESC;

-- 2. Tìm kiếm sản phẩm theo từ khóa
SELECT * FROM products 
WHERE title ILIKE '%máy ảnh%' 
   OR description ILIKE '%máy ảnh%'
ORDER BY created_at DESC;

-- 3. Lọc sản phẩm theo danh mục
SELECT * FROM products 
WHERE category = 'electronics'
ORDER BY created_at DESC;

-- 4. Lọc sản phẩm theo tình trạng
SELECT * FROM products 
WHERE condition = 'new'
ORDER BY created_at DESC;

-- 5. Lọc sản phẩm theo khoảng giá
SELECT * FROM products 
WHERE price BETWEEN 1000000 AND 10000000
ORDER BY price ASC;

-- 6. Lọc sản phẩm theo địa điểm
SELECT * FROM products 
WHERE location = 'hanoi'
ORDER BY created_at DESC;

-- 7. Lọc kết hợp nhiều điều kiện
SELECT * FROM products 
WHERE category = 'electronics' 
  AND condition = 'used' 
  AND price <= 20000000
  AND location IN ('hanoi', 'hcm')
ORDER BY price ASC;

-- 8. Đếm số lượng sản phẩm theo danh mục
SELECT category, COUNT(*) as total_products
FROM products 
GROUP BY category
ORDER BY total_products DESC;

-- 9. Lấy sản phẩm theo ID
SELECT * FROM products 
WHERE id = 1;

-- 10. Thêm sản phẩm mới
INSERT INTO products (title, description, price, category, condition, location, phone, email, seller_name, images, created_at)
VALUES (
    'Tên sản phẩm',
    'Mô tả chi tiết sản phẩm',
    1000000,
    'electronics',
    'used',
    'hanoi',
    '0901234567',
    'email@example.com',
    'Tên người bán',
    ARRAY['url_hình_ảnh'],
    NOW()::text
);

-- 11. Cập nhật thông tin sản phẩm
UPDATE products 
SET title = 'Tên mới', 
    price = 1500000,
    description = 'Mô tả mới'
WHERE id = 1;

-- 12. Xóa sản phẩm
DELETE FROM products 
WHERE id = 1;

-- 13. Tìm sản phẩm giá cao nhất và thấp nhất
SELECT 'Giá cao nhất' as loai, title, price 
FROM products 
WHERE price = (SELECT MAX(price) FROM products)
UNION ALL
SELECT 'Giá thấp nhất' as loai, title, price 
FROM products 
WHERE price = (SELECT MIN(price) FROM products);

-- 14. Thống kê sản phẩm theo tình trạng
SELECT 
    condition,
    COUNT(*) as so_luong,
    AVG(price) as gia_trung_binh,
    MIN(price) as gia_thap_nhat,
    MAX(price) as gia_cao_nhat
FROM products 
GROUP BY condition;

-- 15. Tìm sản phẩm theo seller
SELECT * FROM products 
WHERE seller_name ILIKE '%nguyễn%'
ORDER BY created_at DESC;

-- 16. Lấy 5 sản phẩm mới nhất
SELECT * FROM products 
ORDER BY created_at DESC 
LIMIT 5;

-- 17. Phân trang sản phẩm (trang 1, mỗi trang 10 sản phẩm)
SELECT * FROM products 
ORDER BY created_at DESC 
LIMIT 10 OFFSET 0;

-- 18. Tìm kiếm full-text (nếu có extension)
SELECT *, 
       ts_rank(to_tsvector('vietnamese', title || ' ' || description), 
               plainto_tsquery('vietnamese', 'máy ảnh')) as rank
FROM products 
WHERE to_tsvector('vietnamese', title || ' ' || description) @@ plainto_tsquery('vietnamese', 'máy ảnh')
ORDER BY rank DESC;

-- 19. Thống kê theo địa điểm
SELECT 
    location,
    COUNT(*) as so_luong_san_pham,
    AVG(price) as gia_trung_binh
FROM products 
GROUP BY location
ORDER BY so_luong_san_pham DESC;

-- 20. Tìm sản phẩm có giá gần nhất với giá mong muốn
SELECT *, ABS(price - 5000000) as price_diff
FROM products 
ORDER BY price_diff ASC
LIMIT 5;