# Cơ sở dữ liệu cho trang web bán đồ cũ

## Tổng quan

Thư mục này chứa các file SQL để thiết lập và quản lý cơ sở dữ liệu PostgreSQL cho trang web bán đồ cũ "Chợ Đồ Cũ".

## Các file SQL

### 1. `schema.sql`
- Tạo cấu trúc cơ sở dữ liệu
- Định nghĩa bảng `users` và `products`
- Tạo các index để tối ưu hiệu suất

### 2. `seed.sql`
- Chèn dữ liệu mẫu vào cơ sở dữ liệu
- Bao gồm 8 sản phẩm mẫu đa dạng
- Tạo một số user mẫu

### 3. `queries.sql`
- Các câu truy vấn SQL phổ biến
- Ví dụ về tìm kiếm, lọc, thống kê
- Hướng dẫn sử dụng các chức năng database

## Cách sử dụng

### 1. Thiết lập schema
```bash
psql -h hostname -U username -d database_name -f schema.sql
```

### 2. Chèn dữ liệu mẫu
```bash
psql -h hostname -U username -d database_name -f seed.sql
```

### 3. Sử dụng với ứng dụng
Ứng dụng sẽ tự động kết nối với database thông qua biến môi trường `DATABASE_URL`.

## Cấu trúc bảng

### Bảng `users`
- `id`: Primary key, auto increment
- `username`: Tên đăng nhập (unique)
- `password`: Mật khẩu đã hash
- `created_at`: Thời gian tạo tài khoản

### Bảng `products`
- `id`: Primary key, auto increment
- `title`: Tiêu đề sản phẩm
- `description`: Mô tả chi tiết
- `price`: Giá (số nguyên, đơn vị VNĐ)
- `category`: Danh mục (electronics, fashion, home, books, vehicles, music)
- `condition`: Tình trạng (new, used, repair)
- `location`: Địa điểm (hanoi, hcm, danang, etc.)
- `phone`: Số điện thoại người bán
- `email`: Email người bán (có thể null)
- `seller_name`: Tên người bán
- `images`: Mảng URL hình ảnh
- `created_at`: Thời gian đăng bán

## Index được tạo

- `idx_products_category`: Tối ưu tìm kiếm theo danh mục
- `idx_products_condition`: Tối ưu tìm kiếm theo tình trạng
- `idx_products_location`: Tối ưu tìm kiếm theo địa điểm
- `idx_products_price`: Tối ưu tìm kiếm theo giá
- `idx_products_created_at`: Tối ưu sắp xếp theo thời gian
- `idx_products_title`: Full-text search cho tiêu đề
- `idx_products_description`: Full-text search cho mô tả

## Lưu ý

- Database sử dụng PostgreSQL
- Giá sản phẩm lưu dưới dạng số nguyên (VNĐ)
- Hình ảnh lưu dưới dạng mảng URL
- Hỗ trợ tìm kiếm tiếng Việt với full-text search
- Tất cả thời gian lưu dưới dạng text ISO string

## Kết nối với ứng dụng

Ứng dụng sử dụng Drizzle ORM để kết nối với PostgreSQL thông qua biến môi trường:
- `DATABASE_URL`: Connection string của PostgreSQL
- `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE`: Thông tin kết nối