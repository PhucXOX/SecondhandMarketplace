# Overview

This is a Vietnamese second-hand marketplace web application called "Chợ Đồ Cũ" (Used Goods Market). It's a platform for buying and selling used items, connecting buyers and sellers across Vietnam. The application is built with pure HTML, CSS, and JavaScript for simplicity and performance.

# System Architecture

The application follows a simple static web architecture:

- **Frontend**: Pure HTML5, CSS3, and vanilla JavaScript
- **Data Storage**: JavaScript arrays with sample data (8 products)
- **Database**: SQL files provided for future backend integration
- **Deployment**: Static files served via Python HTTP server
- **Styling**: Custom CSS with responsive design and Font Awesome icons

The architecture prioritizes simplicity, fast loading, and easy maintenance without complex build processes.

# Key Components

## Frontend Components
- **Static HTML Interface**: Single-page application with Vietnamese language support
- **Responsive Design**: Mobile-first approach with Inter font family
- **Interactive Elements**: Search functionality, product listings, and modal forms
- **Font Awesome Icons**: For enhanced UI elements and visual appeal

## Database Schema
- **Users Table**: Authentication and user management
  - Primary key auto-increment ID
  - Unique username constraint
  - Password hashing support
  - Timestamp tracking
- **Products Table**: Core marketplace functionality
  - Comprehensive product information (title, description, price)
  - Category classification (electronics, fashion, books, etc.)
  - Condition tracking (new, used)
  - Location-based filtering
  - Contact information (phone, email)
  - Image array support
  - Text search optimization with Vietnamese language support

## Sample Data
- Pre-populated with 8 diverse product examples
- Includes electronics, fashion, and books categories
- Vietnamese product descriptions and seller information
- Realistic pricing in Vietnamese Dong (VND)

# Data Flow

1. **Product Display**: Static JavaScript array serves initial product data
2. **Search & Filter**: Client-side filtering by category, condition, location, and price range
3. **Database Integration**: Prepared SQL queries for full-text search and filtering
4. **User Interaction**: Form handling for product creation and search functionality

The current implementation uses client-side data management with prepared database queries for future backend integration.

# External Dependencies

- **Font Awesome 6.4.0**: Icon library for UI elements
- **Google Fonts (Inter)**: Typography with Vietnamese character support
- **Unsplash Images**: Placeholder images for product listings
- **PostgreSQL**: Database engine with Vietnamese text search capabilities

All external dependencies are loaded via CDN for simplicity and fast loading times.

# Deployment Strategy

- **Platform**: Replit with Node.js 20 runtime
- **Database**: PostgreSQL 16 module integration
- **Build Process**: npm run build for production optimization
- **Development**: npm run dev with hot reloading on port 5000
- **Production**: npm run start for deployment
- **Scaling**: Autoscale deployment target for traffic management

The deployment configuration supports both development and production environments with automatic scaling capabilities.

# Changelog

Changelog:
- June 24, 2025. Initial setup

# User Preferences

Preferred communication style: Simple, everyday language.