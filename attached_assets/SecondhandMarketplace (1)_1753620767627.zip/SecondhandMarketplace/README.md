# Chợ Đồ Cũ - Trang Web Bán Đồ Cũ

Trang web mua bán đồ cũ đơn giản được xây dựng bằng HTML, CSS, JavaScript thuần túy.

## Tính năng

- **Hiển thị sản phẩm**: Grid layout responsive với thông tin đầy đủ
- **Tìm kiếm**: Tìm kiếm theo tên và mô tả sản phẩm
- **Lọc sản phẩm**: 
  - Theo danh mục (Điện tử, Thời trang, Gia dụng, Sách, Xe cộ)
  - Theo tình trạng (Như mới, Đã sử dụng, Cần sửa chữa)
  - Theo khoảng giá
- **Sắp xếp**: Theo thời gian, giá tăng dần, giá giảm dần
- **Đăng tin**: Form đăng sản phẩm mới
- **Chi tiết sản phẩm**: Modal hiển thị thông tin chi tiết
- **Responsive**: Tương thích mobile và desktop

## Cấu trúc file

```
├── index.html          # Trang chính
├── styles.css          # CSS styling
├── script.js           # JavaScript logic
├── database/           # SQL files
│   ├── schema.sql      # Cấu trúc database
│   ├── seed.sql        # Dữ liệu mẫu
│   ├── queries.sql     # Các truy vấn SQL mẫu
│   └── README.md       # Hướng dẫn database
└── README.md           # File này
```

## Cách sử dụng

1. **Chạy trực tiếp**: Mở file `index.html` trong trình duyệt
2. **Web server**: Sử dụng live server hoặc bất kỳ web server nào

## Dữ liệu

- **Sản phẩm mẫu**: 8 sản phẩm đa dạng với thông tin đầy đủ
- **Lưu trữ**: JavaScript array (có thể tích hợp với database sau)
- **Database SQL**: Có sẵn trong thư mục `database/`

## Công nghệ sử dụng

- **HTML5**: Cấu trúc semantic
- **CSS3**: Flexbox, Grid, Responsive design
- **JavaScript ES6**: DOM manipulation, Event handling
- **Font Awesome**: Icons
- **Google Fonts**: Typography (Inter)

## Tương thích

- Chrome, Firefox, Safari, Edge (modern browsers)
- Mobile responsive
- Screen readers (accessibility support)

## Phát triển

Để mở rộng tính năng:
1. Tích hợp với backend API
2. Thêm authentication
3. Upload hình ảnh thật
4. Payment integration
5. Real-time messaging

## Database

Tham khảo thư mục `database/` để:
- Thiết lập PostgreSQL/MySQL
- Import dữ liệu mẫu
- Sử dụng các truy vấn có sẵn